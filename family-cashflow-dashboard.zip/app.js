// Financial Management Application JavaScript

// Application Data
let appData = {
  "projets_exemple": [
    {
      "nom": "Titre foncier Mejeuh",
      "montant": 2815000,
      "type": "Actif générateur",
      "statut": "En cours",
      "roi_attendu": 12,
      "cash_flow_mensuel": 0,
      "description": "Acquisition terrain pour location future"
    },
    {
      "nom": "Voyage enfants Suisse",
      "montant": 8189592,
      "type": "Passif",
      "statut": "Planifié",
      "roi_attendu": 0,
      "cash_flow_mensuel": -680000,
      "description": "Voyage familial cohésion"
    },
    {
      "nom": "Scolarité enfants",
      "montant": 6500000,
      "type": "Investissement formation",
      "statut": "En cours",
      "roi_attendu": 25,
      "cash_flow_mensuel": -542000,
      "description": "Éducation Uriel, Naelle, Nell-Henri"
    },
    {
      "nom": "Projet IIBA",
      "montant": 2786480,
      "type": "Actif générateur",
      "statut": "Développement",
      "roi_attendu": 18,
      "cash_flow_mensuel": 232000,
      "description": "Business génération revenus passifs"
    }
  ],
  "kpis_actuels": {
    "cash_flow_mensuel": -2200000,
    "ratio_actifs_passifs": 11.3,
    "regle_50_30_20": {
      "besoins": 75,
      "envies": 45,
      "epargne": 5
    },
    "fonds_urgence_mois": 0,
    "revenus_passifs_pct": 18,
    "phase_actuelle": "Stabilisation",
    "revenus_mensuels": 1082000,
    "depenses_mensuelles": 3282000,
    "nombre_actifs": 2,
    "objectif_independance": 30
  }
};

// Charts storage
let charts = {};

// DOM Content Loaded
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM loaded, initializing application...');
    initializeApplication();
});

function initializeApplication() {
    console.log('Initializing application...');
    setupNavigation();
    displayProjects();
    setupProjectForm();
    setupFilters();
    
    // Initialize charts after a short delay to ensure DOM is ready
    setTimeout(() => {
        initializeCharts();
    }, 100);
}

// Navigation Setup
function setupNavigation() {
    console.log('Setting up navigation...');
    const navItems = document.querySelectorAll('.nav-item');
    const pages = document.querySelectorAll('.page');

    console.log('Found nav items:', navItems.length);
    console.log('Found pages:', pages.length);

    navItems.forEach((item, index) => {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            const targetPage = this.getAttribute('data-page');
            console.log(`Navigation clicked: ${targetPage}`);
            
            if (!targetPage) {
                console.error('No data-page attribute found');
                return;
            }
            
            // Update active nav item
            navItems.forEach(nav => nav.classList.remove('active'));
            this.classList.add('active');
            
            // Update active page
            pages.forEach(page => {
                page.classList.remove('active');
                console.log(`Hiding page: ${page.id}`);
            });
            
            const targetPageElement = document.getElementById(targetPage);
            if (targetPageElement) {
                targetPageElement.classList.add('active');
                console.log(`Showing page: ${targetPage}`);
                
                // Refresh charts if on analytics page
                if (targetPage === 'analytics') {
                    setTimeout(refreshAnalyticsCharts, 200);
                }
            } else {
                console.error(`Page element not found: ${targetPage}`);
            }
        });
    });
}

// Chart Initialization
function initializeCharts() {
    console.log('Initializing charts...');
    initializeCashFlowChart();
    initializeAssetsChart();
}

function initializeCashFlowChart() {
    const ctx = document.getElementById('cashFlowChart');
    if (!ctx) {
        console.log('Cash flow chart canvas not found');
        return;
    }

    console.log('Initializing cash flow chart...');

    // Generate sample data for the last 12 months
    const labels = [];
    const cashFlowData = [];
    const currentDate = new Date();
    
    for (let i = 11; i >= 0; i--) {
        const date = new Date(currentDate.getFullYear(), currentDate.getMonth() - i, 1);
        labels.push(date.toLocaleDateString('fr-FR', { month: 'short', year: '2-digit' }));
        // Simulate cash flow trend improving over time
        cashFlowData.push(-3000000 + (i * 100000) + (Math.random() * 200000 - 100000));
    }

    charts.cashFlow = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Cash Flow Mensuel (FCFA)',
                data: cashFlowData,
                borderColor: '#1FB8CD',
                backgroundColor: 'rgba(31, 184, 205, 0.1)',
                fill: true,
                tension: 0.3
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: false,
                    ticks: {
                        callback: function(value) {
                            return new Intl.NumberFormat('fr-FR', {
                                style: 'currency',
                                currency: 'XOF',
                                minimumFractionDigits: 0
                            }).format(value);
                        }
                    }
                }
            },
            plugins: {
                legend: {
                    display: true,
                    position: 'top'
                }
            }
        }
    });
    console.log('Cash flow chart initialized');
}

function initializeAssetsChart() {
    const ctx = document.getElementById('assetsChart');
    if (!ctx) {
        console.log('Assets chart canvas not found');
        return;
    }

    console.log('Initializing assets chart...');

    const totalActifs = appData.projets_exemple
        .filter(p => p.type === 'Actif générateur')
        .reduce((sum, p) => sum + p.montant, 0);
    
    const totalPassifs = appData.projets_exemple
        .filter(p => p.type === 'Passif')
        .reduce((sum, p) => sum + p.montant, 0);
    
    const totalFormation = appData.projets_exemple
        .filter(p => p.type === 'Investissement formation')
        .reduce((sum, p) => sum + p.montant, 0);

    charts.assets = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Actifs Générateurs', 'Passifs', 'Formation'],
            datasets: [{
                data: [totalActifs, totalPassifs, totalFormation],
                backgroundColor: ['#1FB8CD', '#B4413C', '#FFC185'],
                borderWidth: 2,
                borderColor: '#ffffff'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const value = context.parsed;
                            const total = context.dataset.data.reduce((sum, val) => sum + val, 0);
                            const percentage = ((value / total) * 100).toFixed(1);
                            return `${context.label}: ${new Intl.NumberFormat('fr-FR').format(value)} FCFA (${percentage}%)`;
                        }
                    }
                }
            }
        }
    });
    console.log('Assets chart initialized');
}

// Analytics Charts
function refreshAnalyticsCharts() {
    console.log('Refreshing analytics charts...');
    initializeIndependenceChart();
    initializeRevenueExpenseChart();
}

function initializeIndependenceChart() {
    const ctx = document.getElementById('independenceChart');
    if (!ctx) {
        console.log('Independence chart canvas not found');
        return;
    }

    const currentProgress = appData.kpis_actuels.revenus_passifs_pct;
    const target = appData.kpis_actuels.objectif_independance;

    charts.independence = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Progression', 'Restant'],
            datasets: [{
                data: [currentProgress, target - currentProgress],
                backgroundColor: ['#1FB8CD', '#ECEBD5'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '70%',
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `${context.label}: ${context.parsed}%`;
                        }
                    }
                }
            }
        }
    });
}

function initializeRevenueExpenseChart() {
    const ctx = document.getElementById('revenueExpenseChart');
    if (!ctx) {
        console.log('Revenue expense chart canvas not found');
        return;
    }

    const labels = [];
    const revenueData = [];
    const expenseData = [];
    const currentDate = new Date();
    
    for (let i = 11; i >= 0; i--) {
        const date = new Date(currentDate.getFullYear(), currentDate.getMonth() - i, 1);
        labels.push(date.toLocaleDateString('fr-FR', { month: 'short' }));
        
        // Simulate data with some variation
        const baseRevenue = appData.kpis_actuels.revenus_mensuels;
        const baseExpense = appData.kpis_actuels.depenses_mensuelles;
        
        revenueData.push(baseRevenue + (Math.random() * 200000 - 100000));
        expenseData.push(baseExpense + (Math.random() * 300000 - 150000));
    }

    charts.revenueExpense = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'Revenus',
                    data: revenueData,
                    backgroundColor: '#1FB8CD',
                    borderRadius: 4
                },
                {
                    label: 'Dépenses',
                    data: expenseData,
                    backgroundColor: '#B4413C',
                    borderRadius: 4
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return new Intl.NumberFormat('fr-FR').format(value / 1000) + 'k';
                        }
                    }
                }
            },
            plugins: {
                legend: {
                    position: 'top'
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `${context.dataset.label}: ${new Intl.NumberFormat('fr-FR').format(context.parsed.y)} FCFA`;
                        }
                    }
                }
            }
        }
    });
}

// Project Management
function displayProjects() {
    const projectsList = document.getElementById('projectsList');
    if (!projectsList) {
        console.log('Projects list element not found');
        return;
    }

    console.log('Displaying projects...');
    projectsList.innerHTML = '';

    appData.projets_exemple.forEach(project => {
        const projectCard = createProjectCard(project);
        projectsList.appendChild(projectCard);
    });
}

function createProjectCard(project) {
    const card = document.createElement('div');
    card.className = 'project-card';

    const typeClass = project.type === 'Actif générateur' ? 'actif' : 
                     project.type === 'Passif' ? 'passif' : 'formation';

    card.innerHTML = `
        <div class="project-header">
            <h3 class="project-title">${project.nom}</h3>
            <span class="project-type ${typeClass}">${project.type}</span>
        </div>
        <div class="project-details">
            <div class="project-detail">
                <div class="project-detail-label">Montant</div>
                <div class="project-detail-value">${new Intl.NumberFormat('fr-FR').format(project.montant)} FCFA</div>
            </div>
            <div class="project-detail">
                <div class="project-detail-label">Statut</div>
                <div class="project-detail-value">${project.statut}</div>
            </div>
            <div class="project-detail">
                <div class="project-detail-label">ROI Attendu</div>
                <div class="project-detail-value">${project.roi_attendu}%</div>
            </div>
            <div class="project-detail">
                <div class="project-detail-label">Cash Flow</div>
                <div class="project-detail-value ${project.cash_flow_mensuel < 0 ? 'negative' : 'positive'}">
                    ${new Intl.NumberFormat('fr-FR').format(project.cash_flow_mensuel)} FCFA
                </div>
            </div>
        </div>
        <p class="project-description">${project.description}</p>
        ${getProjectAdvice(project)}
    `;

    return card;
}

function getProjectAdvice(project) {
    let advice = '<div class="project-advice"><h4>💡 Conseils des Mentors:</h4>';
    
    if (project.type === 'Actif générateur') {
        advice += `
            <p><strong>Kiyosaki:</strong> Excellent ! Cet actif génère des revenus passifs et vous rapproche du quadrant I.</p>
            <p><strong>Buffett:</strong> Assurez-vous de comprendre parfaitement ce business et son potentiel long terme.</p>
            <p><strong>Ramsey:</strong> Vérifiez que cet investissement n'endette pas votre famille.</p>
        `;
    } else if (project.type === 'Passif') {
        advice += `
            <p><strong>Kiyosaki:</strong> Attention ! Ce passif retire de l'argent de votre poche chaque mois.</p>
            <p><strong>Buffett:</strong> Est-ce vraiment nécessaire ? L'argent pourrait être mieux investi ailleurs.</p>
            <p><strong>Ramsey:</strong> Est-ce un BESOIN ou une ENVIE ? Respecte-t-il votre budget 50/30/20 ?</p>
        `;
    } else {
        advice += `
            <p><strong>Kiyosaki:</strong> L'éducation est un actif qui génère des revenus futurs plus élevés.</p>
            <p><strong>Buffett:</strong> Le meilleur investissement est en vous-même et votre famille.</p>
            <p><strong>Ramsey:</strong> Investir dans l'éducation est toujours rentable à long terme.</p>
        `;
    }
    
    advice += '</div>';
    return advice;
}

// Project Form Handling
function setupProjectForm() {
    const form = document.getElementById('addProjectForm');
    if (!form) {
        console.log('Project form not found');
        return;
    }

    console.log('Setting up project form...');
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const newProject = {
            nom: document.getElementById('projectName').value,
            montant: parseInt(document.getElementById('projectAmount').value),
            type: document.getElementById('projectType').value,
            statut: document.getElementById('projectStatus').value,
            roi_attendu: parseInt(document.getElementById('projectROI').value) || 0,
            cash_flow_mensuel: parseInt(document.getElementById('projectCashFlow').value) || 0,
            description: document.getElementById('projectDescription').value
        };

        // Add to data
        appData.projets_exemple.push(newProject);
        
        // Refresh displays
        displayProjects();
        updateKPIs();
        
        // Reset form and close modal
        form.reset();
        hideAddProjectModal();
        
        // Show success message
        showNotification('Projet ajouté avec succès !', 'success');
    });
}

// Filters
function setupFilters() {
    const typeFilter = document.getElementById('typeFilter');
    const statusFilter = document.getElementById('statusFilter');

    if (typeFilter) {
        typeFilter.addEventListener('change', applyFilters);
    }
    if (statusFilter) {
        statusFilter.addEventListener('change', applyFilters);
    }
}

function applyFilters() {
    const typeFilter = document.getElementById('typeFilter');
    const statusFilter = document.getElementById('statusFilter');
    
    if (!typeFilter || !statusFilter) return;

    const typeValue = typeFilter.value;
    const statusValue = statusFilter.value;

    const filteredProjects = appData.projets_exemple.filter(project => {
        return (typeValue === '' || project.type === typeValue) &&
               (statusValue === '' || project.statut === statusValue);
    });

    displayFilteredProjects(filteredProjects);
}

function displayFilteredProjects(projects) {
    const projectsList = document.getElementById('projectsList');
    if (!projectsList) return;

    projectsList.innerHTML = '';

    if (projects.length === 0) {
        projectsList.innerHTML = '<p class="no-projects">Aucun projet ne correspond aux filtres sélectionnés.</p>';
        return;
    }

    projects.forEach(project => {
        const projectCard = createProjectCard(project);
        projectsList.appendChild(projectCard);
    });
}

// Modal Functions
function showAddProjectModal() {
    console.log('Showing add project modal...');
    const modal = document.getElementById('addProjectModal');
    if (modal) {
        modal.classList.remove('hidden');
    }
}

function hideAddProjectModal() {
    console.log('Hiding add project modal...');
    const modal = document.getElementById('addProjectModal');
    if (modal) {
        modal.classList.add('hidden');
    }
}

// Make functions globally available
window.showAddProjectModal = showAddProjectModal;
window.hideAddProjectModal = hideAddProjectModal;

// KPIs Update
function updateKPIs() {
    console.log('Updating KPIs...');
    // Recalculate KPIs based on current projects
    const totalActifs = appData.projets_exemple
        .filter(p => p.type === 'Actif générateur')
        .reduce((sum, p) => sum + p.montant, 0);
    
    const totalPassifs = appData.projets_exemple
        .filter(p => p.type === 'Passif')
        .reduce((sum, p) => sum + p.montant, 0);
    
    const totalCashFlow = appData.projets_exemple
        .reduce((sum, p) => sum + p.cash_flow_mensuel, 0);
    
    // Update data
    appData.kpis_actuels.cash_flow_mensuel = totalCashFlow;
    appData.kpis_actuels.nombre_actifs = appData.projets_exemple
        .filter(p => p.type === 'Actif générateur').length;
    
    // Refresh charts
    if (charts.assets) {
        charts.assets.destroy();
        setTimeout(() => {
            initializeAssetsChart();
        }, 100);
    }
}

// Notification System
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    
    // Add styles
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 12px 24px;
        border-radius: 8px;
        color: white;
        font-weight: 500;
        z-index: 1001;
        opacity: 0;
        transform: translateY(-20px);
        transition: all 0.3s ease;
    `;
    
    if (type === 'success') {
        notification.style.backgroundColor = '#1FB8CD';
    } else if (type === 'error') {
        notification.style.backgroundColor = '#B4413C';
    } else {
        notification.style.backgroundColor = '#5D878F';
    }
    
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.style.opacity = '1';
        notification.style.transform = 'translateY(0)';
    }, 10);
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.style.opacity = '0';
        notification.style.transform = 'translateY(-20px)';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    }, 3000);
}

// Utility Functions
function formatCurrency(amount) {
    return new Intl.NumberFormat('fr-FR', {
        style: 'currency',
        currency: 'XOF',
        minimumFractionDigits: 0
    }).format(amount);
}

function calculateFinancialPhase() {
    const cashFlow = appData.kpis_actuels.cash_flow_mensuel;
    const revenusPassifs = appData.kpis_actuels.revenus_passifs_pct;
    
    if (cashFlow < 0 || revenusPassifs < 10) {
        return 'Stabilisation';
    } else if (cashFlow >= 0 && revenusPassifs >= 10 && revenusPassifs < 30) {
        return 'Transition';
    } else {
        return 'Expansion';
    }
}

// Event Listeners for Modal Close
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('modal')) {
        hideAddProjectModal();
    }
});

document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        hideAddProjectModal();
    }
});

// Initialize tooltips and interactive elements
document.addEventListener('DOMContentLoaded', function() {
    // Add click handlers for interactive elements
    const kpiCards = document.querySelectorAll('.kpi-card');
    kpiCards.forEach(card => {
        card.addEventListener('click', function() {
            // Add pulse effect
            this.style.transform = 'scale(0.98)';
            setTimeout(() => {
                this.style.transform = 'scale(1)';
            }, 150);
        });
    });

    // Update phase indicator dynamically
    const currentPhase = calculateFinancialPhase();
    const phaseIndicator = document.querySelector('.phase-badge');
    if (phaseIndicator) {
        phaseIndicator.textContent = `🔴 ${currentPhase.toUpperCase()}`;
        phaseIndicator.className = `phase-badge phase-${currentPhase.toLowerCase()}`;
    }
});

// Export for potential future use
window.FinanceApp = {
    data: appData,
    charts: charts,
    showAddProjectModal: showAddProjectModal,
    hideAddProjectModal: hideAddProjectModal,
    updateKPIs: updateKPIs,
    showNotification: showNotification
};